package cat.copernic.rodriguez.albert.m7t1.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.LinkedList;

import cat.copernic.rodriguez.albert.m7t1.R;
import cat.copernic.rodriguez.albert.m7t1.WordListAdapter;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;

    //LLista pel RecycledView
    private final LinkedList<String> mWordList = new LinkedList<>();

    //Variables membres pel RecyclerView i l'adaptador
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });


        //Posem dades inicials a la llista
        for(int i = 0; i < 20; i++)
        {
            mWordList.addLast("Word" + i);
        }

        mWordList.addLast("Word");

        //Get a handle to the Recycler View
        mRecyclerView = root.findViewById(R.id.recyclerview); //root també
        //Create an adapter and supply the data to be displayed.
        mAdapter = new WordListAdapter(getContext(), mWordList);
        //Connect the adapter with the RecyclerView.
        mRecyclerView.setAdapter(mAdapter);
        //Give the RecyclerView a default layout manager.
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        return root;
    }
}